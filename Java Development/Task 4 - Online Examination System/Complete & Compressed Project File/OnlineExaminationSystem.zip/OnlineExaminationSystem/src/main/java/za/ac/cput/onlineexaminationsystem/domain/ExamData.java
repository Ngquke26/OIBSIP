/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.cput.onlineexaminationsystem.domain;

/**
 *
 * @author PC
 */
public class ExamData {
    public static String[]answers = new String [5];
    
    public static String []correctAnswers = {
     "2",
     "%",
    "verb",
    "Nelson Mandela",
     "Java"};
    
    public static int totalQuestions = 5;
    public static int totalTime = 30;//30
}

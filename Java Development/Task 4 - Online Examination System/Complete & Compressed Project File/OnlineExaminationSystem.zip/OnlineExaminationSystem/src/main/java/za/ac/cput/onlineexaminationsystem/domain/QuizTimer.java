/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.cput.onlineexaminationsystem.domain;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import za.ac.cput.onlineexaminationsystem.gui.Results;

/**
 *
 * @author PC
 */
public class QuizTimer {
    public static JLabel timerLabel = new JLabel("Time left: 30s");
    public static Timer timer;
    public static int timeLeft = 30;

    public static void startTimer(JFrame currentFrame) {
        timer = new Timer(1000, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                timeLeft--;
                timerLabel.setText("Time left: " + timeLeft + "s");

                if (timeLeft <= 0) {
                    timer.stop();
                    JOptionPane.showMessageDialog(currentFrame, "Time is up! Exam will be submitted.");
                    new Results();
                    currentFrame.dispose();
                }
            }
        });
        timer.start();
    }
}

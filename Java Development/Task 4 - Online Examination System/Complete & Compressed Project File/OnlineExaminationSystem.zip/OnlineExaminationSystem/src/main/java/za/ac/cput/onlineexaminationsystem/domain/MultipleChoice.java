/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.cput.onlineexaminationsystem.domain;

/**
 *
 * @author PC
 */
public class MultipleChoice {
    private String question;
    private String answer;
    private int marks;
    private int total;
    
}

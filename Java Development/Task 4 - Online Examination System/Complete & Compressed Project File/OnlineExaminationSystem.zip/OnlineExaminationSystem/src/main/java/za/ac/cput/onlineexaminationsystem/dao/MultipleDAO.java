
package za.ac.cput.onlineexaminationsystem.dao;

/**
 *
 * @author PC
 */
public class MultipleDAO {
    
}
